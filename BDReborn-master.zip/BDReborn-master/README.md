# [BDReborn](http://telegramiti.ir)
* **Install Bot**
`````sh
yon.ir/V9b5
`````
